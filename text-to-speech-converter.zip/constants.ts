import { VoiceOption, StyleOption, RateOption, PitchOption } from './types';

export const AVAILABLE_VOICES: VoiceOption[] = [
    { id: 'Kore', name: 'كورِي', description: 'صوت أنثوي، واضح ومهني' },
    { id: 'Puck', name: 'باك', description: 'صوت ذكوري، دافئ وودود' },
    { id: 'Charon', name: 'كارون', description: 'صوت ذكوري، عميق ورسمي' },
    { id: 'Fenrir', name: 'فنرير', description: 'صوت ذكوري، قوي وحيوي' },
    { id: 'Zephyr', name: 'زفير', description: 'صوت أنثوي، هادئ ولطيف' },
];

export const AVAILABLE_STYLES: StyleOption[] = [
    { id: 'Default', name: 'عادي', instruction: '' },
    { id: 'Cheerful', name: 'مرح', instruction: 'انطق النص بنبرة يملؤها الفرح والتفاؤل. استخدم تنوعًا في طبقة الصوت لتعكس الحماس، وأضف وقفات قصيرة وطبيعية لإضفاء إحساس بالبهجة العفوية.' },
    { id: 'Sad', name: 'حزين', instruction: 'انطق النص بنبرة حزينة وعميقة. استخدم وتيرة كلام أبطأ ووقفات أطول للتعبير عن مشاعر الأسى والتعاطف.' },
    { id: 'Professional', name: 'احترافي', instruction: 'انطق النص بصوت احترافي، واضح، وواثق. حافظ على وتيرة متوازنة ونبرة رسمية ومقنعة، مع وقفات محسوبة للتأكيد على النقاط الهامة.' },
    { id: 'Storytelling', name: 'سرد قصصي', instruction: 'احكِ القصة بأسلوب سردي ساحر وجذاب. استخدم وقفات درامية للتشويق، وغير طبقة صوتك ببراعة لتمييز الشخصيات وإضفاء الحيوية على الأحداث.' },
];

export const AVAILABLE_RATES: RateOption[] = [
    { id: 'Slow', name: 'بطيء', instruction: 'بسرعة كلام أبطأ من المعتاد' },
    { id: 'Normal', name: 'عادي', instruction: '' },
    { id: 'Fast', name: 'سريع', instruction: 'بسرعة كلام أسرع من المعتاد' },
];

export const AVAILABLE_PITCHES: PitchOption[] = [
    { id: 'Low', name: 'منخفض', instruction: 'بنبرة صوت منخفضة قليلاً' },
    { id: 'Normal', name: 'عادي', instruction: '' },
    { id: 'High', name: 'مرتفع', instruction: 'بنبرة صوت مرتفعة قليلاً' },
];
