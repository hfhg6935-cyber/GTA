import React from 'react';
import { SpeakerIcon } from './icons/SpeakerIcon';
import { BookIcon } from './icons/BookIcon';
import { UsersIcon } from './icons/UsersIcon';

type Page = 'tts' | 'story' | 'conversation';

interface NavProps {
    currentPage: Page;
    onNavigate: (page: Page) => void;
}

const NavItem: React.FC<{
    icon: React.ReactNode;
    label: string;
    isActive: boolean;
    onClick: () => void;
}> = ({ icon, label, isActive, onClick }) => (
    <button
        onClick={onClick}
        className={`flex-1 flex items-center justify-center gap-2 px-4 py-3 text-sm font-medium transition-colors duration-200 focus:outline-none ${
            isActive
                ? 'text-cyan-300 border-b-2 border-cyan-400 bg-gray-700/50'
                : 'text-gray-400 hover:text-white hover:bg-gray-700/30'
        }`}
        aria-current={isActive ? 'page' : undefined}
    >
        {icon}
        <span>{label}</span>
    </button>
);

export const Nav: React.FC<NavProps> = ({ currentPage, onNavigate }) => {
    return (
        <nav className="flex border-b border-gray-700 bg-gray-800/50">
            <NavItem
                icon={<SpeakerIcon className="w-5 h-5" />}
                label="تحويل النص إلى كلام"
                isActive={currentPage === 'tts'}
                onClick={() => onNavigate('tts')}
            />
            <NavItem
                icon={<BookIcon className="w-5 h-5" />}
                label="توليد قصة"
                isActive={currentPage === 'story'}
                onClick={() => onNavigate('story')}
            />
            <NavItem
                icon={<UsersIcon className="w-5 h-5" />}
                label="توليد محادثة"
                isActive={currentPage === 'conversation'}
                onClick={() => onNavigate('conversation')}
            />
        </nav>
    );
};
