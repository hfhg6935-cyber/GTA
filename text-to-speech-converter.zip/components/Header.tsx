import React from 'react';
import { SpeakerIcon } from './icons/SpeakerIcon';

export const Header: React.FC = () => (
    <div className="text-center space-y-2">
        <div className="flex justify-center items-center gap-3">
            <SpeakerIcon className="w-8 h-8 text-cyan-400" />
            <h1 className="text-3xl md:text-4xl font-bold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 to-fuchsia-500">
                تحويل النص إلى صوت
            </h1>
        </div>
        <p className="text-gray-400 text-md">
            حوّل نصوصك إلى أصوات طبيعية وواقعية
        </p>
    </div>
);