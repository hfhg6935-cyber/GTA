import React from 'react';
import { SpeechRate } from '../types';
import { AVAILABLE_RATES } from '../constants';
import { SpeedometerIcon } from './icons/SpeedometerIcon';

interface RateSelectorProps {
    selectedRate: SpeechRate;
    onRateChange: (rate: SpeechRate) => void;
}

export const RateSelector: React.FC<RateSelectorProps> = ({ selectedRate, onRateChange }) => (
    <div>
        <label htmlFor="rate-select" className="block text-sm font-medium text-gray-300 mb-2">
            سرعة الكلام
        </label>
        <div className="relative">
            <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center pr-3">
                <SpeedometerIcon className="h-5 w-5 text-gray-400" />
            </div>
            <select
                id="rate-select"
                value={selectedRate}
                onChange={(e) => onRateChange(e.target.value as SpeechRate)}
                className="block w-full appearance-none rounded-lg border border-gray-600 bg-gray-700 py-2 pl-10 pr-3 text-white placeholder-gray-400 focus:border-cyan-500 focus:outline-none focus:ring-cyan-500 sm:text-sm"
            >
                {AVAILABLE_RATES.map((rate) => (
                    <option key={rate.id} value={rate.id}>
                        {rate.name}
                    </option>
                ))}
            </select>
        </div>
    </div>
);
