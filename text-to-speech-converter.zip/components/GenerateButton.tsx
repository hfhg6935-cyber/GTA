import React from 'react';
import { LoadingSpinner } from './LoadingSpinner';
import { SparklesIcon } from './icons/SparklesIcon';

interface GenerateButtonProps {
    isLoading: boolean;
    onGenerate: () => void;
}

export const GenerateButton: React.FC<GenerateButtonProps> = ({ isLoading, onGenerate }) => {
    return (
        <button
            onClick={onGenerate}
            disabled={isLoading}
            className={`w-full flex items-center justify-center gap-3 text-lg font-semibold rounded-lg px-6 py-3 transition-all duration-300 ease-in-out focus:outline-none focus:ring-4 focus:ring-opacity-50
            ${isLoading
                ? 'bg-gray-600 cursor-not-allowed'
                : 'bg-gradient-to-r from-cyan-500 to-fuchsia-600 hover:from-cyan-600 hover:to-fuchsia-700 focus:ring-cyan-400 text-white'
            }`}
        >
            {isLoading ? (
                <>
                    <LoadingSpinner />
                    <span>جاري التوليد...</span>
                </>
            ) : (
                <>
                    <SparklesIcon className="w-6 h-6" />
                    <span>توليد الصوت</span>
                </>
            )}
        </button>
    );
};
