
import React from 'react';
import { PlayIcon } from './icons/PlayIcon';
import { StopIcon } from './icons/StopIcon';
import { LoadingSpinner } from './LoadingSpinner';

interface ActionButtonProps {
    isLoading: boolean;
    isPlaying: boolean;
    onGenerate: () => void;
    onStop: () => void;
}

export const ActionButton: React.FC<ActionButtonProps> = ({ isLoading, isPlaying, onGenerate, onStop }) => {
    const handleClick = () => {
        if (isPlaying) {
            onStop();
        } else {
            onGenerate();
        }
    };

    const buttonText = isPlaying ? "إيقاف" : "إنشاء الصوت";
    const Icon = isPlaying ? StopIcon : PlayIcon;

    return (
        <button
            onClick={handleClick}
            disabled={isLoading}
            className={`w-full flex items-center justify-center gap-3 text-lg font-semibold rounded-lg px-6 py-3 transition-all duration-300 ease-in-out focus:outline-none focus:ring-4 focus:ring-opacity-50
            ${isLoading 
                ? 'bg-gray-600 cursor-not-allowed' 
                : isPlaying
                ? 'bg-red-600 hover:bg-red-700 focus:ring-red-500 text-white'
                : 'bg-gradient-to-r from-cyan-500 to-fuchsia-600 hover:from-cyan-600 hover:to-fuchsia-700 focus:ring-cyan-400 text-white'
            }`}
        >
            {isLoading ? (
                <>
                    <LoadingSpinner />
                    <span>جاري الإنشاء...</span>
                </>
            ) : (
                <>
                    <Icon className="w-6 h-6" />
                    <span>{buttonText}</span>
                </>
            )}
        </button>
    );
};
