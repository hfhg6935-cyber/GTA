import React from 'react';
import { PlayIcon } from './icons/PlayIcon';
import { StopIcon } from './icons/StopIcon';

interface PlayButtonProps {
    isPlaying: boolean;
    onPlay: () => void;
    onStop: () => void;
    disabled: boolean;
}

export const PlayButton: React.FC<PlayButtonProps> = ({ isPlaying, onPlay, onStop, disabled }) => {
    const handleClick = () => {
        if (isPlaying) {
            onStop();
        } else {
            onPlay();
        }
    };

    const buttonText = isPlaying ? "إيقاف" : "تشغيل الصوت";
    const Icon = isPlaying ? StopIcon : PlayIcon;

    return (
        <button
            onClick={handleClick}
            disabled={disabled}
            className={`w-full flex items-center justify-center gap-3 text-lg font-semibold rounded-lg px-6 py-3 transition-all duration-300 ease-in-out focus:outline-none focus:ring-4 focus:ring-opacity-50
            ${disabled
                ? 'bg-gray-700 text-gray-500 cursor-not-allowed'
                : isPlaying
                ? 'bg-red-600 hover:bg-red-700 focus:ring-red-500 text-white'
                : 'bg-blue-600 hover:bg-blue-700 focus:ring-blue-500 text-white'
            }`}
        >
            <Icon className="w-6 h-6" />
            <span>{buttonText}</span>
        </button>
    );
};
