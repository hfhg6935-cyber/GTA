
import React from 'react';

export const Footer: React.FC = () => (
    <footer className="w-full max-w-2xl text-center text-gray-500 text-sm mt-6">
        <p>&copy; {new Date().getFullYear()} - تم إنشاؤه بواسطة Gemini. جميع الحقوق محفوظة.</p>
    </footer>
);
