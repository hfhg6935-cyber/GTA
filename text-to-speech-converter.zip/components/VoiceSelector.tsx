
import React from 'react';
import { Voice } from '../types';
import { AVAILABLE_VOICES } from '../constants';
import { UserIcon } from './icons/UserIcon';

interface VoiceSelectorProps {
    selectedVoice: Voice;
    onVoiceChange: (voice: Voice) => void;
}

export const VoiceSelector: React.FC<VoiceSelectorProps> = ({ selectedVoice, onVoiceChange }) => (
    <div>
        <label htmlFor="voice-select" className="block text-sm font-medium text-gray-300 mb-2">
            اختر الصوت
        </label>
        <div className="relative">
            <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center pr-3">
                <UserIcon className="h-5 w-5 text-gray-400" />
            </div>
            <select
                id="voice-select"
                value={selectedVoice}
                onChange={(e) => onVoiceChange(e.target.value as Voice)}
                className="block w-full appearance-none rounded-lg border border-gray-600 bg-gray-700 py-2 pl-10 pr-3 text-white placeholder-gray-400 focus:border-cyan-500 focus:outline-none focus:ring-cyan-500 sm:text-sm"
            >
                {AVAILABLE_VOICES.map((voice) => (
                    <option key={voice.id} value={voice.id}>
                        {voice.name} - {voice.description}
                    </option>
                ))}
            </select>
        </div>
    </div>
);
