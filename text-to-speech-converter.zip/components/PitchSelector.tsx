import React from 'react';
import { SpeechPitch } from '../types';
import { AVAILABLE_PITCHES } from '../constants';
import { SignalIcon } from './icons/SignalIcon';

interface PitchSelectorProps {
    selectedPitch: SpeechPitch;
    onPitchChange: (pitch: SpeechPitch) => void;
}

export const PitchSelector: React.FC<PitchSelectorProps> = ({ selectedPitch, onPitchChange }) => (
    <div>
        <label htmlFor="pitch-select" className="block text-sm font-medium text-gray-300 mb-2">
            طبقة الصوت
        </label>
        <div className="relative">
            <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center pr-3">
                <SignalIcon className="h-5 w-5 text-gray-400" />
            </div>
            <select
                id="pitch-select"
                value={selectedPitch}
                onChange={(e) => onPitchChange(e.target.value as SpeechPitch)}
                className="block w-full appearance-none rounded-lg border border-gray-600 bg-gray-700 py-2 pl-10 pr-3 text-white placeholder-gray-400 focus:border-cyan-500 focus:outline-none focus:ring-cyan-500 sm:text-sm"
            >
                {AVAILABLE_PITCHES.map((pitch) => (
                    <option key={pitch.id} value={pitch.id}>
                        {pitch.name}
                    </option>
                ))}
            </select>
        </div>
    </div>
);
