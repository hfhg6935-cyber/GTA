
import React from 'react';

interface TextAreaProps {
    text: string;
    onTextChange: (text: string) => void;
    placeholder: string;
}

export const TextArea: React.FC<TextAreaProps> = ({ text, onTextChange, placeholder }) => (
    <textarea
        value={text}
        onChange={(e) => onTextChange(e.target.value)}
        placeholder={placeholder}
        rows={6}
        className="block w-full resize-none rounded-lg border border-gray-600 bg-gray-700 p-3 text-white placeholder-gray-400 focus:border-cyan-500 focus:outline-none focus:ring-cyan-500 sm:text-sm transition duration-150"
    />
);
