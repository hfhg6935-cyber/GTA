
import React from 'react';
import { DownloadIcon } from './icons/DownloadIcon';

interface DownloadButtonProps {
    onDownload: () => void;
    disabled: boolean;
}

export const DownloadButton: React.FC<DownloadButtonProps> = ({ onDownload, disabled }) => {
    return (
        <button
            onClick={onDownload}
            disabled={disabled}
            aria-label="Download audio"
            className={`w-full flex items-center justify-center gap-3 text-lg font-semibold rounded-lg px-6 py-3 transition-all duration-300 ease-in-out focus:outline-none focus:ring-4 focus:ring-opacity-50
            ${disabled
                ? 'bg-gray-700 text-gray-500 cursor-not-allowed'
                : 'bg-green-600 hover:bg-green-700 focus:ring-green-500 text-white'
            }`}
        >
            <DownloadIcon className="w-6 h-6" />
            <span>تحميل الصوت</span>
        </button>
    );
};
