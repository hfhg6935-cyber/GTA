import React, { useState, useCallback, useRef, useEffect } from 'react';
import { GoogleGenAI, Modality } from "@google/genai";
import { AVAILABLE_VOICES } from '../constants';
import { Voice } from '../types';
import { ErrorDisplay } from '../components/ErrorDisplay';
import { AudioVisualizer } from '../components/AudioVisualizer';
import { decode, decodeAudioData, createWavBlob } from '../utils/audioUtils';
import { DownloadButton } from '../components/DownloadButton';
import { PlayButton } from '../components/PlayButton';
import { LoadingSpinner } from '../components/LoadingSpinner';
import { UsersIcon } from '../components/icons/UsersIcon';
import { SparklesIcon } from '../components/icons/SparklesIcon';

const ConversationGeneratorPage: React.FC = () => {
    // Script generation state
    const [topic, setTopic] = useState('التخطيط لعطلة نهاية الأسبوع');
    const [speaker1Name, setSpeaker1Name] = useState('سالم');
    const [speaker2Name, setSpeaker2Name] = useState('نورة');
    const [script, setScript] = useState('');
    const [isGeneratingScript, setIsGeneratingScript] = useState(false);

    // Audio generation state
    const [speaker1Voice, setSpeaker1Voice] = useState<Voice>('Puck');
    const [speaker2Voice, setSpeaker2Voice] = useState<Voice>('Kore');
    const [isGeneratingAudio, setIsGeneratingAudio] = useState(false);
    const [generatedAudio, setGeneratedAudio] = useState<string | null>(null);
    const [error, setError] = useState<string | null>(null);
    const [isPlaying, setIsPlaying] = useState<boolean>(false);
    
    const audioContextRef = useRef<AudioContext | null>(null);
    const audioSourceRef = useRef<AudioBufferSourceNode | null>(null);
    const analyserRef = useRef<AnalyserNode | null>(null);
    const audioBufferRef = useRef<AudioBuffer | null>(null);

    const stopPlayback = useCallback(() => {
        if (audioSourceRef.current) {
            audioSourceRef.current.stop();
            audioSourceRef.current.disconnect();
            audioSourceRef.current = null;
        }
        setIsPlaying(false);
    }, []);

    useEffect(() => {
        audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
        return () => {
            stopPlayback();
            audioContextRef.current?.close();
        };
    }, [stopPlayback]);

    const handleGenerateScript = useCallback(async () => {
        if (!topic.trim() || !speaker1Name.trim() || !speaker2Name.trim()) {
            setError('الرجاء ملء جميع الحقول لتوليد الحوار.');
            return;
        }
        if (isGeneratingScript) return;

        setIsGeneratingScript(true);
        setError(null);
        setScript('');
        setGeneratedAudio(null);
        audioBufferRef.current = null;
        stopPlayback();

        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
            const prompt = `اكتب حوارًا واقعيًا وطبيعيًا للغاية، لا يقل عن 4 تبادلات، بين ${speaker1Name} و ${speaker2Name} حول: ${topic}. يجب أن يعكس الحوار تدفق محادثة بشرية حقيقية، بتعبيراتها العفوية وتوقفاتها الطبيعية. الأهم من كل شيء: النص يجب أن يكون باللغة العربية الفصحى النقية، خالٍ تمامًا وبشكل مطلق من أي خطأ إملائي أو نحوي. الدقة اللغوية المطلوبة هي 100%، دون أي استثناء. حافظ على التنسيق التالي بدقة:\n${speaker1Name}: [كلام المتحدث الأول]\n${speaker2Name}: [كلام المتحدث الثاني]`;
            const response = await ai.models.generateContent({
                model: 'gemini-2.5-flash',
                contents: prompt,
            });
            setScript(response.text);
        } catch (e: any) {
            console.error(e);
            setError(`حدث خطأ أثناء توليد الحوار: ${e.message}`);
        } finally {
            setIsGeneratingScript(false);
        }
    }, [topic, speaker1Name, speaker2Name, isGeneratingScript, stopPlayback]);
    
    const handleGenerateAudio = useCallback(async () => {
        if (!script) {
            setError("يجب توليد الحوار أولاً.");
            return;
        }
        if (isGeneratingAudio) return;

        stopPlayback();
        setIsGeneratingAudio(true);
        setError(null);
        setGeneratedAudio(null);
        audioBufferRef.current = null;

        if (audioContextRef.current?.state === 'suspended') {
            await audioContextRef.current.resume();
        }

        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
            const response = await ai.models.generateContent({
                model: "gemini-2.5-flash-preview-tts",
                contents: [{ parts: [{ text: script }] }],
                config: {
                    responseModalities: [Modality.AUDIO],
                    speechConfig: {
                        multiSpeakerVoiceConfig: {
                            speakerVoiceConfigs: [
                                { speaker: speaker1Name, voiceConfig: { prebuiltVoiceConfig: { voiceName: speaker1Voice } } },
                                { speaker: speaker2Name, voiceConfig: { prebuiltVoiceConfig: { voiceName: speaker2Voice } } }
                            ]
                        }
                    }
                }
            });
            const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
            if (base64Audio && audioContextRef.current) {
                setGeneratedAudio(base64Audio);
                const decodedBuffer = await decodeAudioData(decode(base64Audio), audioContextRef.current, 24000, 1);
                audioBufferRef.current = decodedBuffer;
            } else {
                throw new Error("لم يتم تلقي بيانات صوتية.");
            }
        } catch(e: any) {
            console.error(e);
            setError(`حدث خطأ أثناء توليد الصوت: ${e.message}`);
        } finally {
            setIsGeneratingAudio(false);
        }
    }, [script, speaker1Name, speaker1Voice, speaker2Name, speaker2Voice, isGeneratingAudio, stopPlayback]);

    const handlePlay = useCallback(async () => {
        if (!audioBufferRef.current || isPlaying || !audioContextRef.current) return;
        stopPlayback();
        if (audioContextRef.current.state === 'suspended') {
            await audioContextRef.current.resume();
        }
        const source = audioContextRef.current.createBufferSource();
        source.buffer = audioBufferRef.current;
        const analyser = audioContextRef.current.createAnalyser();
        analyser.fftSize = 256;
        analyserRef.current = analyser;
        source.connect(analyser);
        analyser.connect(audioContextRef.current.destination);
        source.onended = () => setIsPlaying(false);
        source.start();
        audioSourceRef.current = source;
        setIsPlaying(true);
    }, [isPlaying, stopPlayback]);
    
    const handleDownload = useCallback(async () => {
        if (!generatedAudio) return;
        try {
            const pcmData = decode(generatedAudio);
            const blob = createWavBlob(pcmData, 24000, 1);
            const fileName = 'gemini-conversation.wav';

            // Modern approach: File System Access API
            if ('showSaveFilePicker' in window) {
                try {
                    const handle = await (window as any).showSaveFilePicker({
                        suggestedName: fileName,
                        types: [{
                            description: 'WAV Audio File',
                            accept: { 'audio/wav': ['.wav'] },
                        }],
                    });
                    const writable = await handle.createWritable();
                    await writable.write(blob);
                    await writable.close();
                    return; // Success, exit
                } catch (err: any) {
                    // AbortError is expected if the user cancels the save dialog.
                    if (err.name === 'AbortError') {
                        return;
                    }
                    console.error('File System Access API failed, falling back.', err);
                    // Fall through to the legacy method
                }
            }
            
            // Legacy approach: create object URL and click a link
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = fileName;
            document.body.appendChild(a);
            a.click();
            URL.revokeObjectURL(url);
            a.remove();
        } catch (e: any) {
            setError(`فشل تحميل الملف: ${e.message}`);
        }
    }, [generatedAudio]);

    const isLoading = isGeneratingAudio || isGeneratingScript;

    return (
        <div className="space-y-6">
            <div className="text-center space-y-2">
                <div className="flex justify-center items-center gap-3">
                    <UsersIcon className="w-8 h-8 text-cyan-400" />
                    <h1 className="text-3xl md:text-4xl font-bold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 to-fuchsia-500">
                        مولّد المحادثات
                    </h1>
                </div>
                <p className="text-gray-400 text-md">
                    أنشئ حوارات واقعية بين شخصيتين
                </p>
            </div>
            
            <div className="p-4 bg-gray-900/50 rounded-lg border border-gray-700 space-y-4">
                <h3 className="text-lg font-semibold text-cyan-300">1. إعدادات الحوار</h3>
                <div>
                    <label className="block text-sm font-medium text-gray-300 mb-1">موضوع الحوار</label>
                    <input type="text" value={topic} onChange={e => setTopic(e.target.value)} className="block w-full rounded-lg border border-gray-600 bg-gray-700 p-2 text-white placeholder-gray-400 focus:border-cyan-500 focus:outline-none focus:ring-cyan-500 sm:text-sm"/>
                </div>
                <div className="grid grid-cols-2 gap-4">
                    <div>
                        <label className="block text-sm font-medium text-gray-300 mb-1">اسم المتحدث الأول</label>
                        <input type="text" value={speaker1Name} onChange={e => setSpeaker1Name(e.target.value)} className="block w-full rounded-lg border border-gray-600 bg-gray-700 p-2 text-white focus:border-cyan-500 focus:outline-none focus:ring-cyan-500 sm:text-sm"/>
                    </div>
                     <div>
                        <label className="block text-sm font-medium text-gray-300 mb-1">صوت المتحدث الأول</label>
                        <select value={speaker1Voice} onChange={e => setSpeaker1Voice(e.target.value as Voice)} className="block w-full appearance-none rounded-lg border border-gray-600 bg-gray-700 p-2 text-white focus:border-cyan-500 focus:outline-none focus:ring-cyan-500 sm:text-sm">
                            {AVAILABLE_VOICES.map(v => <option key={v.id} value={v.id}>{v.name}</option>)}
                        </select>
                    </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                    <div>
                        <label className="block text-sm font-medium text-gray-300 mb-1">اسم المتحدث الثاني</label>
                        <input type="text" value={speaker2Name} onChange={e => setSpeaker2Name(e.target.value)} className="block w-full rounded-lg border border-gray-600 bg-gray-700 p-2 text-white focus:border-cyan-500 focus:outline-none focus:ring-cyan-500 sm:text-sm"/>
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-300 mb-1">صوت المتحدث الثاني</label>
                        <select value={speaker2Voice} onChange={e => setSpeaker2Voice(e.target.value as Voice)} className="block w-full appearance-none rounded-lg border border-gray-600 bg-gray-700 p-2 text-white focus:border-cyan-500 focus:outline-none focus:ring-cyan-500 sm:text-sm">
                            {AVAILABLE_VOICES.map(v => <option key={v.id} value={v.id}>{v.name}</option>)}
                        </select>
                    </div>
                </div>
                 <button onClick={handleGenerateScript} disabled={isGeneratingScript} className="w-full flex items-center justify-center gap-2 text-md font-semibold rounded-lg px-4 py-2 transition-all duration-300 ease-in-out bg-fuchsia-600 hover:bg-fuchsia-700 focus:ring-fuchsia-500 text-white disabled:bg-gray-600 disabled:cursor-not-allowed">
                     {isGeneratingScript ? <><LoadingSpinner/> <span>جاري توليد الحوار...</span></> : <><span>توليد نص الحوار</span></>}
                 </button>
            </div>
            
            <ErrorDisplay error={error} />

            {script && (
                <div className="p-4 bg-gray-900/50 rounded-lg border border-gray-700 space-y-4">
                    <h3 className="text-lg font-semibold text-cyan-300">2. الحوار والصوت</h3>
                    <div className="bg-gray-900 p-3 rounded-lg text-gray-300 whitespace-pre-wrap max-h-40 overflow-y-auto">
                        {script}
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <button onClick={handleGenerateAudio} disabled={!script || isLoading} className="w-full flex items-center justify-center gap-3 text-lg font-semibold rounded-lg px-6 py-3 transition-all duration-300 ease-in-out bg-gradient-to-r from-cyan-500 to-fuchsia-600 hover:from-cyan-600 hover:to-fuchsia-700 focus:ring-cyan-400 text-white disabled:bg-gray-600 disabled:cursor-not-allowed">
                             {isGeneratingAudio ? <><LoadingSpinner/><span>جاري...</span></> : <><SparklesIcon className="w-6 h-6"/><span>توليد الصوت</span></>}
                        </button>
                        <PlayButton isPlaying={isPlaying} onPlay={handlePlay} onStop={stopPlayback} disabled={!generatedAudio || isLoading}/>
                        <DownloadButton onDownload={handleDownload} disabled={!generatedAudio || isLoading}/>
                    </div>
                    <AudioVisualizer analyser={analyserRef.current} isPlaying={isPlaying} />
                </div>
            )}
        </div>
    );
};

export default ConversationGeneratorPage;