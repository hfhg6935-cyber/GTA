import React, { useState, useCallback, useRef, useEffect } from 'react';
import { GoogleGenAI, Modality } from "@google/genai";
import { AVAILABLE_VOICES, AVAILABLE_STYLES, AVAILABLE_RATES, AVAILABLE_PITCHES } from '../constants';
import { Voice, SpeakingStyle, SpeechRate, SpeechPitch } from '../types';
import { Header } from '../components/Header';
import { VoiceSelector } from '../components/VoiceSelector';
import { StyleSelector } from '../components/StyleSelector';
import { RateSelector } from '../components/RateSelector';
import { PitchSelector } from '../components/PitchSelector';
import { TextArea }  from '../components/TextArea';
import { ErrorDisplay } from '../components/ErrorDisplay';
import { AudioVisualizer } from '../components/AudioVisualizer';
import { decode, decodeAudioData, createWavBlob } from '../utils/audioUtils';
import { DownloadButton } from '../components/DownloadButton';
import { GenerateButton } from '../components/GenerateButton';
import { PlayButton } from '../components/PlayButton';

interface TextToSpeechPageProps {
    initialText: string;
    initialStyle: SpeakingStyle;
}

const TextToSpeechPage: React.FC<TextToSpeechPageProps> = ({ initialText, initialStyle }) => {
    const [text, setText] = useState<string>(initialText);
    const [selectedVoice, setSelectedVoice] = useState<Voice>(AVAILABLE_VOICES[0].id);
    const [selectedStyle, setSelectedStyle] = useState<SpeakingStyle>(initialStyle);
    const [selectedRate, setSelectedRate] = useState<SpeechRate>('Normal');
    const [selectedPitch, setSelectedPitch] = useState<SpeechPitch>('Normal');
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);
    const [isPlaying, setIsPlaying] = useState<boolean>(false);
    const [generatedAudio, setGeneratedAudio] = useState<string | null>(null);

    const audioContextRef = useRef<AudioContext | null>(null);
    const audioSourceRef = useRef<AudioBufferSourceNode | null>(null);
    const analyserRef = useRef<AnalyserNode | null>(null);
    const audioBufferRef = useRef<AudioBuffer | null>(null);

    const stopPlayback = useCallback(() => {
        if (audioSourceRef.current) {
            audioSourceRef.current.stop();
            audioSourceRef.current.disconnect();
            audioSourceRef.current = null;
        }
        if (analyserRef.current) {
            analyserRef.current.disconnect();
            analyserRef.current = null;
        }
        setIsPlaying(false);
    }, []);

    useEffect(() => {
        audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
        return () => {
            stopPlayback();
            audioContextRef.current?.close();
        };
    }, [stopPlayback]);
    
    useEffect(() => {
        setText(initialText);
        setSelectedStyle(initialStyle);
        setGeneratedAudio(null);
        setIsPlaying(false);
        setError(null);
        stopPlayback();
    }, [initialText, initialStyle, stopPlayback]);

    const handleGenerateSpeech = useCallback(async () => {
        if (!text.trim()) {
            setError("الرجاء إدخال نص لتحويله.");
            return;
        }
        if (isLoading) return;

        stopPlayback();
        setIsLoading(true);
        setError(null);
        setGeneratedAudio(null);
        audioBufferRef.current = null;
        
        if (audioContextRef.current?.state === 'suspended') {
            await audioContextRef.current.resume();
        }

        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });

            const style = AVAILABLE_STYLES.find(s => s.id === selectedStyle);
            const rate = AVAILABLE_RATES.find(r => r.id === selectedRate);
            const pitch = AVAILABLE_PITCHES.find(p => p.id === selectedPitch);

            const instructions = [
                style?.instruction,
                rate?.instruction,
                pitch?.instruction
            ].filter(Boolean).join('، ');
            
            const textToGenerate = instructions ? `${instructions}: "${text}"` : text;

            const response = await ai.models.generateContent({
                model: "gemini-2.5-flash-preview-tts",
                contents: [{ parts: [{ text: textToGenerate }] }],
                config: {
                    responseModalities: [Modality.AUDIO],
                    speechConfig: {
                        voiceConfig: {
                            prebuiltVoiceConfig: { voiceName: selectedVoice },
                        },
                    },
                },
            });
            
            const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;

            if (base64Audio && audioContextRef.current) {
                setGeneratedAudio(base64Audio);
                const decodedBuffer = await decodeAudioData(
                    decode(base64Audio),
                    audioContextRef.current,
                    24000,
                    1,
                );
                audioBufferRef.current = decodedBuffer;
            } else {
                throw new Error("لم يتم تلقي أي بيانات صوتية من الواجهة البرمجية.");
            }

        } catch (e: any) {
            console.error(e);
            setGeneratedAudio(null);
            audioBufferRef.current = null;
            setError(`حدث خطأ: ${e.message}`);
        } finally {
            setIsLoading(false);
        }
    }, [text, selectedVoice, selectedStyle, selectedRate, selectedPitch, isLoading, stopPlayback]);

    const handlePlay = useCallback(async () => {
        if (!audioBufferRef.current || isPlaying || !audioContextRef.current) return;

        stopPlayback();

        if (audioContextRef.current.state === 'suspended') {
            await audioContextRef.current.resume();
        }
        
        const source = audioContextRef.current.createBufferSource();
        source.buffer = audioBufferRef.current;

        const analyser = audioContextRef.current.createAnalyser();
        analyser.fftSize = 256;
        analyserRef.current = analyser;

        source.connect(analyser);
        analyser.connect(audioContextRef.current.destination);
        
        source.onended = () => {
           setIsPlaying(false);
           if (audioSourceRef.current === source) {
             audioSourceRef.current = null;
           }
        };

        source.start();
        audioSourceRef.current = source;
        setIsPlaying(true);

    }, [isPlaying, stopPlayback]);

    const handleDownload = useCallback(async () => {
        if (!generatedAudio) return;
        try {
            const pcmData = decode(generatedAudio);
            const blob = createWavBlob(pcmData, 24000, 1);
            const fileName = 'gemini-tts-audio.wav';

            // Modern approach: File System Access API
            if ('showSaveFilePicker' in window) {
                try {
                    const handle = await (window as any).showSaveFilePicker({
                        suggestedName: fileName,
                        types: [{
                            description: 'WAV Audio File',
                            accept: { 'audio/wav': ['.wav'] },
                        }],
                    });
                    const writable = await handle.createWritable();
                    await writable.write(blob);
                    await writable.close();
                    return; // Success, exit
                } catch (err: any) {
                    // AbortError is expected if the user cancels the save dialog.
                    if (err.name === 'AbortError') {
                        return;
                    }
                    console.error('File System Access API failed, falling back.', err);
                    // Fall through to the legacy method
                }
            }
            
            // Legacy approach: create object URL and click a link
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.style.display = 'none';
            a.href = url;
            a.download = fileName;
            document.body.appendChild(a);
            a.click();
            window.URL.revokeObjectURL(url);
            a.remove();

        } catch (e: any) {
            console.error("Download failed", e);
            setError(`فشل تحميل الملف الصوتي: ${e.message}`);
        }
    }, [generatedAudio]);

    return (
        <div className="space-y-6">
            <Header />
            
            <div className="space-y-4">
                <div className="grid grid-cols-2 md:grid-cols-2 gap-4">
                    <VoiceSelector 
                        selectedVoice={selectedVoice} 
                        onVoiceChange={setSelectedVoice}
                    />
                    <StyleSelector
                        selectedStyle={selectedStyle}
                        onStyleChange={setSelectedStyle}
                    />
                    <RateSelector
                        selectedRate={selectedRate}
                        onRateChange={setSelectedRate}
                    />
                    <PitchSelector
                        selectedPitch={selectedPitch}
                        onPitchChange={setSelectedPitch}
                    />
                </div>
                <TextArea
                    text={text}
                    onTextChange={setText}
                    placeholder="أدخل النص هنا..."
                />
            </div>
            
            <ErrorDisplay error={error} />

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <GenerateButton
                    isLoading={isLoading}
                    onGenerate={handleGenerateSpeech}
                />
                <PlayButton
                    isPlaying={isPlaying}
                    onPlay={handlePlay}
                    onStop={stopPlayback}
                    disabled={!generatedAudio || isLoading}
                />
                <DownloadButton
                    onDownload={handleDownload}
                    disabled={!generatedAudio || isLoading}
                />
            </div>
            
            <AudioVisualizer analyser={analyserRef.current} isPlaying={isPlaying} />
        </div>
    );
};

export default TextToSpeechPage;