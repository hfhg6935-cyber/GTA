import React, { useState, useCallback } from 'react';
import { GoogleGenAI } from "@google/genai";
import { TextArea } from '../components/TextArea';
import { ErrorDisplay } from '../components/ErrorDisplay';
import { LoadingSpinner } from '../components/LoadingSpinner';
import { BookIcon } from '../components/icons/BookIcon';
import { SpeakerIcon } from '../components/icons/SpeakerIcon';
import { SpeakingStyle } from '../types';

interface StoryGeneratorPageProps {
    onNavigateToTts: (text: string, style: SpeakingStyle) => void;
}

const StoryGeneratorPage: React.FC<StoryGeneratorPageProps> = ({ onNavigateToTts }) => {
    const [prompt, setPrompt] = useState('قصة عن فارس شجاع وتنين لطيف');
    const [story, setStory] = useState<string>('');
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);

    const handleGenerateStory = useCallback(async () => {
        if (!prompt.trim()) {
            setError('الرجاء إدخال فكرة للقصة.');
            return;
        }
        if (isLoading) return;

        setIsLoading(true);
        setError(null);
        setStory('');

        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
            const fullPrompt = `اكتب قصة إبداعية للأطفال لا تقل عن 150 كلمة، بناءً على الفكرة: "${prompt}". يجب أن تكون القصة ذات أسلوب إنساني طبيعي تمامًا، ومليئة بالمشاعر والتعبيرات الحية التي تجعلها تبدو وكأنها من تأليف كاتب بشري محترف. يجب أن تكون النهاية سعيدة. الأهم من كل شيء: النص يجب أن يكون باللغة العربية الفصحى النقية، خالٍ تمامًا وبشكل مطلق من أي خطأ إملائي أو نحوي. الدقة اللغوية المطلوبة هي 100%، دون أي استثناء.`;
            const response = await ai.models.generateContent({
                model: 'gemini-2.5-flash',
                contents: fullPrompt,
            });

            setStory(response.text);
        } catch (e: any) {
            console.error(e);
            setError(`حدث خطأ أثناء توليد القصة: ${e.message}`);
        } finally {
            setIsLoading(false);
        }
    }, [prompt, isLoading]);

    return (
        <div className="space-y-6">
            <div className="text-center space-y-2">
                <div className="flex justify-center items-center gap-3">
                    <BookIcon className="w-8 h-8 text-cyan-400" />
                    <h1 className="text-3xl md:text-4xl font-bold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 to-fuchsia-500">
                        مولّد القصص
                    </h1>
                </div>
                <p className="text-gray-400 text-md">
                    حوّل أفكارك إلى قصص شيقة
                </p>
            </div>

            <div className="space-y-4">
                <label htmlFor="story-prompt" className="block text-sm font-medium text-gray-300 mb-2">
                    أدخل فكرة القصة
                </label>
                <TextArea
                    text={prompt}
                    onTextChange={setPrompt}
                    placeholder="مثال: قطة تسافر إلى القمر..."
                />
            </div>

            <ErrorDisplay error={error} />
            
            <button
                onClick={handleGenerateStory}
                disabled={isLoading}
                className={`w-full flex items-center justify-center gap-3 text-lg font-semibold rounded-lg px-6 py-3 transition-all duration-300 ease-in-out focus:outline-none focus:ring-4 focus:ring-opacity-50
                ${isLoading
                    ? 'bg-gray-600 cursor-not-allowed'
                    : 'bg-gradient-to-r from-cyan-500 to-fuchsia-600 hover:from-cyan-600 hover:to-fuchsia-700 focus:ring-cyan-400 text-white'
                }`}
            >
                {isLoading ? (
                    <>
                        <LoadingSpinner />
                        <span>جاري كتابة القصة...</span>
                    </>
                ) : (
                    <>
                        <BookIcon className="w-6 h-6" />
                        <span>توليد القصة</span>
                    </>
                )}
            </button>

            {story && (
                 <div className="space-y-4 pt-4 border-t border-gray-700">
                     <h2 className="text-xl font-bold text-cyan-300">القصة المولّدة:</h2>
                     <div className="bg-gray-900 p-4 rounded-lg text-gray-300 whitespace-pre-wrap max-h-60 overflow-y-auto">
                        {story}
                     </div>
                     <button
                        onClick={() => onNavigateToTts(story, 'Storytelling')}
                        className="w-full flex items-center justify-center gap-3 text-lg font-semibold rounded-lg px-6 py-3 transition-all duration-300 ease-in-out bg-green-600 hover:bg-green-700 focus:ring-green-500 text-white"
                     >
                        <SpeakerIcon className="w-6 h-6" />
                        <span>الاستماع إلى القصة</span>
                     </button>
                 </div>
            )}
        </div>
    );
};

export default StoryGeneratorPage;