export type Voice = 'Kore' | 'Puck' | 'Charon' | 'Fenrir' | 'Zephyr';

export interface VoiceOption {
    id: Voice;
    name: string;
    description: string;
}

export type SpeakingStyle = 'Default' | 'Cheerful' | 'Sad' | 'Professional' | 'Storytelling';

export interface StyleOption {
    id: SpeakingStyle;
    name: string;
    instruction: string;
}

export type SpeechRate = 'Slow' | 'Normal' | 'Fast';

export interface RateOption {
    id: SpeechRate;
    name: string;
    instruction: string;
}

export type SpeechPitch = 'Low' | 'Normal' | 'High';

export interface PitchOption {
    id: SpeechPitch;
    name: string;
    instruction: string;
}
