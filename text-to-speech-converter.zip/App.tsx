import React, { useState } from 'react';
import { Nav } from './components/Nav';
import TextToSpeechPage from './pages/TextToSpeechPage';
import StoryGeneratorPage from './pages/StoryGeneratorPage';
import ConversationGeneratorPage from './pages/ConversationGeneratorPage';
import { Footer } from './components/Footer';
import { SpeakingStyle } from './types';

type Page = 'tts' | 'story' | 'conversation';

const App: React.FC = () => {
    const [page, setPage] = useState<Page>('tts');
    const [initialTextForTts, setInitialTextForTts] = useState<string>('مرحباً بعالم الذكاء الاصطناعي! يمكنك تحويل أي نص إلى كلام مسموع بجودة عالية.');
    const [initialStyleForTts, setInitialStyleForTts] = useState<SpeakingStyle>('Default');

    const navigateToTts = (text: string, style: SpeakingStyle = 'Default') => {
        setInitialTextForTts(text);
        setInitialStyleForTts(style);
        setPage('tts');
    };

    const renderPage = () => {
        switch (page) {
            case 'story':
                return <StoryGeneratorPage onNavigateToTts={navigateToTts} />;
            case 'conversation':
                return <ConversationGeneratorPage />;
            case 'tts':
            default:
                // Use key to force re-mount and state reset when navigating from story page
                return <TextToSpeechPage key={initialTextForTts} initialText={initialTextForTts} initialStyle={initialStyleForTts} />;
        }
    };

    return (
        <div dir="rtl" className="min-h-screen bg-gray-900 flex flex-col items-center justify-center p-4 font-sans text-white">
            <div className="w-full max-w-2xl bg-gray-800 rounded-2xl shadow-2xl border border-gray-700 overflow-hidden">
                <Nav currentPage={page} onNavigate={setPage} />
                <main className="p-6 md:p-8">
                    {renderPage()}
                </main>
            </div>
            <Footer />
        </div>
    );
};

export default App;